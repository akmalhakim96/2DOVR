#!/bin/bash

time=`date  +%m%d%H%M%Y`

if [ $# = 1 ]; then
  ssh root@$1 date  $time &
  exit
fi

while read line
do
  firstc=`echo $line | cut -c 1`
  if [ $firstc != "#" ];then
    echo $line
    ssh root@$line date  $time &
  fi
done < hosts
