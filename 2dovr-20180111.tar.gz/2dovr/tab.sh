dir=RaspberryPi/2dovr
echo $dir
gnome-terminal --tab --working-directory=$dir ,\
 --tab --working-directory=$dir ,\
 --tab --working-directory=$dir/build ,\
 --tab --working-directory=$dir
