#!/bin/bash

HOSTAPDCONF="hostapd.conf"

if [ $# = 0 ]; then
  echo "please input interface name and my ip address"
  exit
fi

#generating hostapd.conf
echo "interface=$1" > $HOSTAPDCONF
echo "driver=nl80211" >> $HOSTAPDCONF
echo "ssid=2dovr-robot" >> $HOSTAPDCONF
echo "wpa_passphrase=jagarico" >> $HOSTAPDCONF

echo "auth_algs=3" >> $HOSTAPDCONF
echo "hw_mode=g" >> $HOSTAPDCONF
echo "wpa=3"  >> $HOSTAPDCONF
echo "wpa_key_mgmt=WPA-PSK" >> $HOSTAPDCONF
echo "wpa_pairwise=TKIP CCMP" >> $HOSTAPDCONF
echo "rsn_pairwise=TKIP CCMP" >> $HOSTAPDCONF

INTERFACE=$1
ADDRESS=$2
MASK=255.255.255.0

sudo killall hostapd
sudo /etc/init.d/network-manager stop
sudo ifconfig $INTERFACE $ADDRESS netmask $MASK
sudo hostapd $HOSTAPDCONF
