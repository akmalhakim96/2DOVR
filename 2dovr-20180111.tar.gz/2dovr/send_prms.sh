#!/bin/bash

if [ $# = 1 ]; then
  scp prms root@$1:/tmp
  exit
fi

while read line
do
  firstc=`echo $line | cut -c 1`
  if [ $firstc != "#" ];then
    scp prms root@${line}:/tmp
  fi
done < hosts
