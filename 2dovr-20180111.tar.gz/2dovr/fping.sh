#!/bin/bash

fping -f hosts
