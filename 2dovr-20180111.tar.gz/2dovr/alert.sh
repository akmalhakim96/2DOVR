#!/bin/bash

command="mpg321"
sound="sub_data/sound/Warning-Alarm02-mp3/Warning-Alarm02-1L.mp3"

$command $sound
