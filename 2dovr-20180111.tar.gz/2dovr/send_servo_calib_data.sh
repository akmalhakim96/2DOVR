#!/bin/bash

if [ $# = 1 ]; then
  scp sub_data/servo_data/servo_calib_data/$1_servo_calib_data root@$1:/tmp
  exit
fi

while read line
do
  firstc=`echo $line | cut -c 1`
  if [ $firstc != "#" ];then
    scp sub_data/servo_data/servo_calib_data/${line}_servo_calib_data root@${line}:/tmp
  fi
done < hosts
