#!/bin/bash

killall pvm
killall pvmd

while read line
do
  firstc=`echo $line | cut -c 1`
  if [ $firstc != "#" ];then
    addlists="$addlists add $line\n"
  fi
done < hosts

echo -e $addlists | pvm
