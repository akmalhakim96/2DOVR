#!/bin/bash

if [ $# = 1 ]; then
  ssh root@$1 "killall 2dovr" &
  ssh root@$1 "killall pixy" &
  exit
fi

while read line
do
  firstc=`echo $line | cut -c 1`
  if [ $firstc != "#" ];then
    echo $line
    ssh root@${line} "killall 2dovr" &
    ssh root@${line} "killall pixy" &
  fi
done < hosts
