#!/bin/bash

if [ $# = 1 ]; then
  ssh root@$1 "shutdown -h now"
  exit
fi

while read line
do
  firstc=`echo $line | cut -c 1`
  if [ $firstc != "#" ];then
    echo $line
    ssh root@$line "shutdown -h now" &
  fi
done < hosts
