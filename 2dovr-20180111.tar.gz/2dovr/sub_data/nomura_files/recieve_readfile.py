# -*- coding: utf-8 -*-
#!/usr/bin/python//
# recieve_ver5.py
# CC-BY-SA T.Nomura 2017 11/27
import time
import socket
import threading
import datetime
import struct
from datetime import datetime
import re
import sys
import signal

global run

run = 1

def handler(signal, frame):
    run = 0

signal.signal(signal.SIGINT, handler)

HOST = sys.argv[2]    # 自分(受信側)のIPアドレス
PORT = 1001
#multicast_group='224.0.0.1'
multicast_group='225.1.1.1'
offset = 12
num = 1
loop = 0

markerset_name, number_of_marker = [], []
markersetname_length, marker_byte = [], []

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
# 繰り返して同じ(HOST,PORT)を使うために，SO_REUSEADDRオプションが必要
s.bind(('', PORT))
s.setsockopt(socket.IPPROTO_IP,
             socket.IP_ADD_MEMBERSHIP,
            socket.inet_aton(multicast_group)+socket.inet_aton(HOST))


#ファイルからマーカーセット名等を読み込む
for i in open(sys.argv[3]).readlines():
   data = i[:-1].split(' ')
   if num % 2 != 0:
      markerset_name += [str(data[1])]
   else:
      number_of_marker += [int(data[1])]
      loop += 1

   num += 1

#バイト数を計算
for j in range(loop):
   length = len(markerset_name[j])
   marker_b = number_of_marker[j]
   markersetname_length += [int(length)]
   marker_byte += [int(marker_b) * 4 * 3]

#Open Ouput File
today=datetime.now()
filename=today.strftime("/tmp/%Y%m%d_" + sys.argv[1] + "_mcdata.xy")
f = open(filename, 'w')     #座標データを出力するファイル
#g = open('test.binary.dat', 'w')     #バイナリデータを出力するファイル

#Write File Header
today_header=today.strftime("#" + "%F %T" + "\n")
f.write(today_header)

while run==1:
   d = datetime.now()
   data = s.recv(1024)

   date_str = d.strftime("%H:%M:%S.%f" + "\n")
   f.write(date_str)

   for x in range(loop):
      name = struct.unpack_from("<5sx",data,offset)
      offset += int(markersetname_length[x]) + 5
      xyz = struct.unpack_from("<15fx",data,offset)
      xyz = re.sub('[(),]','',str(xyz))
#      xyz = round(xyz,2)   #座標データを小数点第２位で四捨五入する
      f.write(str(xyz) + '\n')
      offset += int(marker_byte[x]) + 64

   f.write('\n')
   offset = 12

s.close()
