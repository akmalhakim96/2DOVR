#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define HOSTS 4
#define START 60
#define END 180

int main(int argc,char** argv){

  FILE* fp;
  fp = fopen(argv[1],"r");
  if(fp == NULL){
    printf("file open error\n");
    exit(0);
  }

  double time;
  int i;
  double dis;
  double dis_sum=0;
  int cnt_ave=0;
  char* tok;

  char line[200];
  while( (fgets(line,200,fp)) != NULL){

    if( line[0] == '#') continue;


    tok = strtok( line, " " );
    time = atof(tok);

    for(i=0;i<HOSTS;i++){
      tok = strtok( NULL, " " );
    }

    tok = strtok( NULL, " ");

    if(tok == NULL) continue;
    dis = atof(tok);


    if(START <= time && time <= END){
      dis_sum += dis;
      cnt_ave++;
    }

    //printf("%lf\n",dis_sum);

    //fprintf(out,"%lf %lf %lf %d %d\n",time,theta_,dis_,ncnt,cnt);

  }

  printf("%s %lf\n",argv[1],dis_sum/cnt_ave);

  return 0;
}
