#!/bin/bash

files=`ls | grep 2dovr`

for file in ${files[@]}
do
  if [[ $file == *"trc" ]];then
    #echo $file

    name=`echo $file | cut -d "-" -f 1`
    #echo $name
  fi

  if [[ $name != $prev ]];then

    echo $name
    date=`echo $name| cut -d "_" -f 1`
    kaime=`echo $name | cut -d "_" -f 3 | sed -e 's/[^0-9]//g'`
    take=`echo $name | cut -d "_" -f 4 | sed -e 's/[^0-9]//g'`

    #echo $date
    #echo $kaime
    #echo $take

    ######ここに処理を記述しましょう######

    #args date kaime take startf endf intervalf
    cplot.sh $date $kaime $take


    #################################
  fi

  prev=$name
done
