#!/bin/bash

date=$1
kaime=$2
take=$3
fps=30
start=$4
end=$5
#markernum=0
dir=plotdata

if [ $# = 0 ]; then
  echo 'arg : date kaime take start end nonuse'
  exit
fi

########ここを変えてください#######
host1=rp041
host2=rpi120
host3=rp092
host4=rp093
host5=
oost6=

color1=red
color2=green
color3=blue
color4=purple
color5=
color6=

host1_mn=1
host2_mn=1
host3_mn=0
host4_mn=1

size=2
pt1=7
pt2=5

declare -a hosts=($host1 $host2 $host3 $host4)
declare -a colors=($color1 $color2 $color3 $color4)
declare -a host_mns=($host1_mn $host2_mn $host3_mn $host4_mn)
###############################

declare -a col1s=()
declare -a col2s=()
#col1=`expr $markernum \* 3 \+ 3`
#col2=`expr $markernum \* 3 \+ 4`

for ((i = 0; i < ${#hosts[@]}; i++)) {
  col1s[i]=`expr ${host_mns[i]} \* 3 \+ 3`
  col2s[i]=`expr ${host_mns[i]} \* 3 \+ 4`
}

declare -a files=()
for ((i = 0; i < ${#hosts[@]}; i++)) {
  files[i]="${date}_2dovr_${kaime}kaime_take${take}_1-${hosts[i]}.trc"
}
#echo ${files[@]}

outfile="$dir/${date}_2dovr_${kaime}kaime_take${take}_t${start}to${end}.eps"

mkdir -p $dir
#rm $dir/*
rm  -f $outfile


for ((i = 0; i < ${#hosts[@]}; i++)) {
  plot="$plot\"${files[i]}\" every ::$start*$fps::$start*$fps u (\$${col1s[i]} / 1000):(\$${col2s[i]} / 1000) ps $size pt $pt1 lc rgb \"${colors[i]}\"  notitle,"
}

for ((i = 0; i < ${#hosts[@]}; i++)) {
  plot="$plot\"${files[i]}\" every ::$end*$fps::$end*$fps u (\$${col1s[i]} / 1000):(\$${col2s[i]} / 1000) ps $size pt $pt2 lc rgb \"${colors[i]}\" notitle,"
}

for ((i = 0; i < ${#hosts[@]}; i++)) {
  lt=`expr $i \+ 1`
  plot="$plot\"${files[i]}\" every ::$start*$fps::$end*$fps u (\$${col1s[i]} / 1000):(\$${col2s[i]} / 1000) w l lt $lt lc rgb \"${colors[i]}\"t sprintf(\"%s t=%d to %d\",\"${hosts[i]}\",$start,$end),"
}

plot="${plot}2*cos(t),2*sin(t) lc rgb \"black\" lt 1  notitle,"
plot=`echo $plot | rev | cut -c 2- | rev`
plot="plot $plot"




gnuplot  << EOF

reset

host1="rp041"
host2="rpi120"
host3="rp092"
host4="rp093"

date="$date"
kaime=$kaime
take=$take

file1=sprintf("%s_2dovr_%dkaime_take%d_1-%s.trc",date,kaime,take,host1)
file2=sprintf("%s_2dovr_%dkaime_take%d_1-%s.trc",date,kaime,take,host2)
file3=sprintf("%s_2dovr_%dkaime_take%d_1-%s.trc",date,kaime,take,host3)
file4=sprintf("%s_2dovr_%dkaime_take%d_1-%s.trc",date,kaime,take,host4)

fps=$fps
start=$start
end=$end
#markernum=$markernum

set xr [-2:2]
set yr [-2:2]
set xtics 1
set ytics 1
set xl "x[m]"
set yl "y[m]"
set size square
set sample 100
set parametric

set term postscript eps enhanced color size 3in,3in font "Helvetica,14"
set output "$outfile"

cl1="red"
cl2="green"
cl3="blue"
cl4="purple"

size=2
pt1=7
pt2=5

set title sprintf("%s-%dkaime-take%d",date,kaime,take)

#col1=$markernum*3+1+2
#col2=$markernum*3+2+2

$plot

q

EOF
