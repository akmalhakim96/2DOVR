#!/bin/bash

files=`ls clusterdata | grep cluster.dat | grep -v cluster.eps`

#rm tplotdata/*.eps

for file in ${files[@]}
do
  #echo $file
  clusave clusterdata/${file}
done
