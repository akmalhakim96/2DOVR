#!/bin/bash

echo plot.shの中身のホストの数は手で書き換えてください

files=`ls | grep 2dovr`

for file in ${files[@]}
do
  if [[ $file == *"trc" ]];then
    #echo $file

    name=`echo $file | cut -d "-" -f 1`
    #echo $name
  fi

  if [[ $name != $prev ]];then

    echo $name
    date=`echo $name| cut -d "_" -f 1`
    kaime=`echo $name | cut -d "_" -f 3 | sed -e 's/[^0-9]//g'`
    take=`echo $name | cut -d "_" -f 4 | sed -e 's/[^0-9]//g'`

    #echo $date
    #echo $kaime
    #echo $take

    ######ここに処理を記述しましょう######

    plot.sh $date $kaime $take 0 60
    plot.sh $date $kaime $take 60 120
    plot.sh $date $kaime $take 120 180

    #################################
  fi

  prev=$name
done
