#!/bin/bash

date=$1
kaime=$2
take=$3
dir=clusterdata

if [ $# = 0 ]; then
  echo 'arg : date kaime take'
  exit
fi

mkdir -p $dir
#rm $dir/*

#######ここを変えてください########

hosts=4

declare -a colors=(red green blue purple)
himo_color=orange

size=0.8
declare -a pts=(6 4 8 10)
pt_len=6

###############################

file="$dir/${date}_2dovr_${kaime}kaime_take${take}_cluster.dat"

for ((i = 0; i < $hosts; i++)) {
  num=`expr $i \+ 2`
  plot="$plot\"${file}\" u 1:${num} w lp ps $size pt ${pts[i]} lc rgb \"${colors[i]}\"  notitle,"
}
num=`expr $hosts \+ 2`
plot="${plot}\"${file}\" u 1:${num} w lp pt $pt_len lc rgb \"$himo_color\" lt 1  notitle axes x1y2,"
plot=`echo $plot | rev | cut -c 2- | rev`
plot="plot $plot"

gnuplot  << EOF

reset


date="$date"
kaime=$kaime
take=$take
dir="$dir"

file=sprintf("%s/%s_2dovr_%dkaime_take%d_cluster.dat",dir,date,kaime,take)

#markernum=$markernum

set ytics nomirror
set y2tics
set xlabel "time[sec]"
set ylabel "num of robots"
set y2label "mean of distance between nearest robots[m]"

set xr [0:180]
set yr [2:$hosts]
set y2r [0:1]
set xtics 30
set ytics 1
#set size square
#set sample 100
#set parametric

set term postscript eps enhanced color font "Helvetica,14"
set output "$dir/${date}_2dovr_${kaime}kaime_take${take}_cluster.eps"

set title sprintf("%s-%dkaime-take%d",date,kaime,take)

#plot file u 1:2 w lp pt 6 lc rgb "red" t "1st cluster",\
#file u 1:3 w lp pt 6 lc rgb "green" t "2nd cluster",\
#file u 1:4 w lp pt 6 lc rgb "blue" t "3rd cluster",\
#file u 1:5 w lp pt 6 lc rgb "purple" t "4th cluster"

$plot

q

EOF
