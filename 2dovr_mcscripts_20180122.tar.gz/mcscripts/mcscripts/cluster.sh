#!/bin/bash

date=$1
kaime=$2
take=$3
fps=30
start=$4 #frame
end=$5 #frame
interval=$6 #frame interval
#markernum=0
#col1=`expr $markernum \* 3 \+ 3`
#col2=`expr $markernum \* 3 \+ 4`
dir=clusterdata

if [ $# = 0 ]; then
  echo 'arg : date kaime take start end interval'
  exit
fi

########ここを変えてください#######
host1=rp041
host2=rpi120
host3=rp092
host4=rp093

host1_mn=1
host2_mn=1
host3_mn=0
host4_mn=1

declare -a hosts=($host1 $host2 $host3 $host4)
declare -a host_mns=($host1_mn $host2_mn $host3_mn $host4_mn)

tree_height=1
###############################

declare -a col1s=()
declare -a col2s=()
#col1=`expr $markernum \* 3 \+ 3`
#col2=`expr $markernum \* 3 \+ 4`

for ((i = 0; i < ${#hosts[@]}; i++)) {
  col1s[i]=`expr ${host_mns[i]} \* 3 \+ 3`
  col2s[i]=`expr ${host_mns[i]} \* 3 \+ 4`
}

declare -a files=()
for ((i = 0; i < ${#hosts[@]}; i++)) {
  files[i]="${date}_2dovr_${kaime}kaime_take${take}_1-${hosts[i]}.trc"
}
#echo ${files[@]}

outfile="$dir/${date}_2dovr_${kaime}kaime_take${take}_cluster.dat"

mkdir -p $dir
#rm $dir/*
rm  -f $outfile

echo "#time sorted_cluster_robots mean_of_string_length" > $outfile
echo "#tree_height=$tree_height" >> $outfile


while [ $start -le $end ]
do

  echo $start
  #echo $file
  low=`expr $start \+ 7`
  #echo $low

  echo  ",x,y" > snapdata

  errflag=0

  for ((i = 0; i < ${#hosts[@]}; i++)) {
    printf "%s," ${hosts[i]} >> snapdata
    c1=`sed -n ${low}p ${files[i]} | cut  -f ${col1s[i]}`
    c2=`sed -n ${low}p ${files[i]} | cut  -f ${col2s[i]}`
    if [[ $c1 = "" ]];then
      errflag=1
    fi
    if [[ $c2 = "" ]];then
      errflag=1
    fi
    c1=`echo "scale=4;  $c1/1000" | bc`
    c2=`echo "scale=4;  $c2/1000" | bc`
    printf "%.4lf,%.4lf\n" $c1 $c2 >> snapdata
  }

  if [ $errflag = 0 ];then
  #  R --vanilla --slave --args $tree_height < cluster.R
  #Rscript cluster.R $tree_height
  cluster.R


    while read line
    do
      declare -a counts=()
      for ((i = 0; i < ${#hosts[@]}; i++)) {
        num=`expr ${i} \+ 1`
        #echo $num
        counts[i]=`echo $line | sed "s/${num}/${num}\n/g" | grep -c "${num}"`
      }

      counts_sorted=`for item in "${counts[@]}"; do echo "$item"; done | sort -rn`
      echo $counts_sorted

      max=`echo $counts_sorted | cut -d " " -f 1`
      sec=`echo "scale=4;  $start/$fps" | bc`
      #echo $max

    done < clustering_result

    himo_sum=0
    himo_num=0
    while read line
    do
      for ((i = 1; i < ${#hosts[@]}; i++)) {
        height=`echo $line | cut -d " " -f ${i}`
        echo $height
        if [[ `echo "$height < 1" | bc` == 1 ]];then
          himo_sum=`echo "scale=4; $himo_sum+$height" | bc`
          himo_num=`expr $himo_num \+ 1`
        fi
      }
    done < clustering_height

    if [[ $himo_num -eq 0 ]];then
      himo_mean=" "
    else
      himo_mean=`echo "scale=4; $himo_sum/$himo_num" | bc | sed -e 's/^\./0./g'`
    fi
    echo himo_mean $himo_mean
    echo himo_num $himo_num
    echo himo_sum $himo_sum

    echo $sec $counts_sorted $himo_mean >> $outfile

  else
    echo Removed
  fi

  start=`expr $start \+ $interval`
done
