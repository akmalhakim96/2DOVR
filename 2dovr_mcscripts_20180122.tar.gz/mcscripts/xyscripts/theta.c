#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define HOSTS 4
#define START 180
#define END 300

int main(int argc,char** argv){

  FILE* fp;
  fp = fopen(argv[1],"r");
  if(fp == NULL){
    printf("file open error\n");
    exit(0);
  }

  FILE* out = fopen(argv[2],"w");
  if(out == NULL){
    printf("file write error\n");
    exit(0);
  }

  double time;
  double theta[HOSTS];
  double dis[HOSTS];
  int visible[HOSTS];
  int i;
  double theta_sum=0;
  double dis_sum=0;
  int cnt_ave=0;

  char line[200];
  while( (fgets(line,200,fp)) != NULL){

    if( line[0] != '#'){
      for(i=0;i<HOSTS;i++){
        //printf("%s\n",line);
        sscanf(line,"%*s %lf %*d %*d %*lf %*lf %*d %lf %*d %lf %d\n",&time,&theta[i],&dis[i],&visible[i]);
        //printf("fe %lf %lf %d\n",theta[i],dis[i],visible[i]);
        fgets(line,200,fp);
      }
    }

    //calc theta
    int ncnt=0;
    double theta_=1;
    for(i=0;i<HOSTS;i++){
      if(visible[i] == 1) ncnt++;
      theta_ *= cos(theta[i]);
    }
    if(ncnt >= 2) theta_=0;

    //calc distance
    int cnt=0;
    double dis_=0;
    for(i=0;i<HOSTS;i++){
      if(visible[i] == 0){
        dis_ += dis[i];
        cnt++;
      }
    }
    if(cnt != 0) dis_ /= cnt;
    else dis_ = 0;
    
    if(START <= time && time <= END){
      theta_sum += theta_;
      dis_sum += dis_;
      cnt_ave++;
    }

    //printf("%lf %lf %d %d\n",theta_,dis_,ncnt,cnt);

    fprintf(out,"%lf %lf %lf %d %d\n",time,theta_,dis_,ncnt,cnt);

  }
  
  printf("%s %lf %lf\n",argv[1],theta_sum/cnt_ave,dis_sum/cnt_ave);

  fclose(out);
  return 0;
}
