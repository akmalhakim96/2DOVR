#!/bin/bash

file=$1

#rm tplotdata/$1.eps

gnuplot  << EOF

reset

set ytics nomirror
set y2tics
set xl "time [sec]"
set yl "product of theta of object"
set y2l "mean of distance from object"
set xr [0:180]
set yr [0.8:1]
set y2r [0:2]

set term postscript eps enhanced color font "Helvetica,14"
set output "tplotdata/$file.eps"

plot "tplotdata/$file" u 1:2 w l t "theta",\
"tplotdata/$file" u 1:3 w l t "distance" axes x1y2

EOF
