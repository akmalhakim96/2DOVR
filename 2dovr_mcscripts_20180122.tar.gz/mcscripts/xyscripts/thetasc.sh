#!/bin/bash

files=`ls | grep bassedat`

mkdir -p tplotdata

for file in ${files[@]}
do
  theta $file tplotdata/$file.dat
done
