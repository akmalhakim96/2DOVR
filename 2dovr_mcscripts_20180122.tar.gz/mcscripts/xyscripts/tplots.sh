#!/bin/bash

files=`ls tplotdata | grep bassedat.xy.dat | grep -v bassedat.xy.dat.eps`

#rm tplotdata/*.eps

for file in ${files[@]}
do
  tplot.sh $file
done
