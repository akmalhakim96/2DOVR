#!/bin/bash

if [ $# = 1 ]; then
  scp build/pixy build/2dovr build/runservo build/pipixy build/plsgen build/runservolinear root@$1:/tmp
  exit
fi

while read line
do
  firstc=`echo $line | cut -c 1`
  if [ $firstc != "#" ];then
    scp build/pixy build/2dovr build/runservo build/pipixy build/plsgen build/runservolinear root@${line}:/tmp
  fi
done < hosts
