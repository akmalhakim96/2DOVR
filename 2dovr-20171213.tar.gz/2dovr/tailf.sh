#!/bin/bash

tail -f /tmp/basse.dat
