#!/bin/bash

rm -r xydata/*
