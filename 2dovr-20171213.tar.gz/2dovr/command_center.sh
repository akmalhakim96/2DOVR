#!/bin/bash

echo "Welcome to 2dovr Command Center!!"


while [ "$input" != "q" ]; do
  echo ""
  echo "1 -> ./make.sh"
  echo "2 -> ./send_binary.sh"
  echo "3 -> ./send_servo_calib_data"
  echo "4 -> sudo ./pvmsetup.sh"
  echo "5 -> ./send_killall.sh"
  echo "6 -> ./send_shutdown.sh"
  echo "7 -> ./iyashinbo.sh"
  echo "8 -> ./recv_xyfiles.sh"
  echo "9 -> ./send_date.sh"
  echo "0 -> ./fping.sh"
  echo "a -> ./vi hosts"
  echo "b -> sudo ./iyashinbo.sh"
  echo "c -> ./rmtmp.sh"
  echo "q -> exit"
  echo "please input key"

  read input

  no=`echo $input | cut -d " " -f 1`
  arg=`echo $input | cut -d " " -f 2 -s`
  arg2=`echo $input | cut -d " " -f 3 -s`

  #echo $no
  #echo $arg

  case "$no" in
    "1" ) ./make.sh;;
    "2" ) ./send_binary.sh $arg;;
    "3" ) ./send_servo_calib_data.sh $arg;;
    "4" ) sudo ./pvmsetup.sh;;
    "5" ) ./send_killall.sh $arg;;
    "6" ) ./send_shutdown.sh $arg;;
    "7" ) ./iyashinbo.sh $arg;;
    "8" ) ./recv_xyfiles.sh $arg;;
    "9" ) ./send_date.sh $arg $arg2;;
    "0" ) ./fping.sh;;
    "a" ) vi hosts;;
    "b" ) sudo ./iyashinbo.sh $arg;;
    "c" ) ./rmtmp.sh
  esac

done
