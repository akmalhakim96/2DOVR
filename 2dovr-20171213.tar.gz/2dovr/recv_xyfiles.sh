#!/bin/bash

dir=xydata_`date +%Y%m%d`
mkdir -p ./xydata/$dir

if [ $# = 1 ]; then
  scp root@$1:/tmp/*.xy ./xydata/$dir/
  exit
fi

while read line
do
  firstc=`echo $line | cut -c 1`
  if [ $firstc != "#" ];then
    scp root@$line:/tmp/*.xy ./xydata/$dir
  fi
done < hosts

sudo cp /tmp/*.xy ./xydata/$dir
ls /tmp/*.xy
user=`whoami`
sudo chown $user ./xydata/$dir/*.xy
sudo chgrp $user ./xydata/$dir/*.xy
