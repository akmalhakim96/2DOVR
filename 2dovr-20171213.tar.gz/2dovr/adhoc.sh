#!/bin/bash

if [ $# = 0 ]; then
  echo "argument:interface_name ESSID channel my_ip_addres subnet_mask WEP_key"
  exit
fi

# name of wireless interface
INTF=$1
# essid for the interface
ESSID=$2
# mode
MODE="ad-hoc"
# channel
CHANNEL=$3
# IP address for the interface
ADDR=$4
# subnet mask
MASK=$5
# period between commands
PROD="0.5s"
#KEY=6D61-706C-65
KEY=$6

ifconfig $INTF down
sleep $PROD

echo $INTF
echo "mode"
iwconfig $INTF mode $MODE
sleep $PROD

echo "channel"
iwconfig $INTF channel $CHANNEL
sleep $PROD

echo "essid"
iwconfig $INTF essid $ESSID
sleep $PROD

echo "key"
iwconfig $INTF key $KEY
sleep $PROD

ifconfig $INTF $ADDR netmask $MASK

#route add default gw $ROUTER $INTF
#route add -net 172.16.11.0 metric 0 netmask $MASK $INTF
