#!/bin/bash
CC=../gcc-linaro-6.3.1-2017.05-x86_64_armv8l-linux-gnueabihf/bin/armv8l-linux-gnueabihf-gcc
INCLUDE=-I./include
LIBS=-L./lib
OPT=

$CC src/2dovr.c -pthread -lpigpio -lrt -lpvm3 -lm -o build/2dovr  $INCLUDE $LIBS $OPT
$CC src/pixy2.c  -lpvm3 -lm -o build/pixy  $INCLUDE $LIBS $OPT
$CC src/runservo.c -lm -lpigpio -pthread -o build/runservo $INCLUDE $LIBS $OPT
$CC src/pipixy.c -lpigpio -pthread -o build/pipixy $INCLUDE $LIBS $OPT
$CC src/plsgen.c -lpigpio -pthread -o build/plsgen $INCLUDE $LIBS $OPT
$CC src/runservolinear.c -lpigpio -pthread -lm -o build/runservolinear $INCLUDE $LIBS $OPT

gcc -o build/basse src/basse.c -lpvm3 $OPT
