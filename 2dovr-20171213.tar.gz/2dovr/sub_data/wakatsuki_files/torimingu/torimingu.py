# -*- coding: utf8 -*-
# I am track2.py
# http://qiita.com/odaman68000/items/ae28cf7bdaf4fa13a65b

import cv2
import numpy as np

directory='/home/wakatsuki/opencv_color_20_full_1011/171120b/'
output_file='20171120_2dovr_15kaime_take3.avi'

def find_rect_of_target_color(image):
  # imageをHSV空間へ変換する
  hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV_FULL)

  # h,s成分を取り出す
  #h = hsv[:, :, 0]
  #s = hsv[:, :, 1]

  #mask = np.zeros(h.shape, dtype=np.uint8)

  # 取り出したい色（pink gomibako）の部分に255を代入
  #mask[((h>238) & (h<242)) & ((s>120)&(s<150))] = 255
  #mask[((h>238) & (h<242)) & ((s>0)&(s<128))] = 255

  # 取得する色の範囲を指定する
  #lower = np.array([230, 10, 100])
  #upper = np.array([245, 120, 255])
  lower = np.array([250, 255, 255])
  upper = np.array([250, 255, 255])
 
  # 指定した色に基づいたマスク画像の生成
  mask = cv2.inRange(hsv, lower, upper)

  # 輪郭の配列として色の塊を取り出す
  contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
  rects = []
  for contour in contours:
    # 輪郭から凸形状を抜き出す
    approx = cv2.convexHull(contour)
    # 凸形状を囲む矩形の(x,y,width,height)をとりだす．
    rect = cv2.boundingRect(approx)
    # 配列rectsに追加
    rects.append(np.array(rect))
  return rects


if __name__ == "__main__":

  # カメラを指定する．
  capture = cv2.VideoCapture('test.webm')
  #capture = cv2.VideoCapture(1)

  #表示などするとき用の縮小サイズ
  size=(640,640)

  # OUTPUT FILE
  fourcc = cv2.cv.CV_FOURCC('x','v','i','d')
  out = cv2.VideoWriter(directory+output_file,fourcc, 15.0, size)

  # キャプチャーの解像度指定
  # Kodak SP360 4K で大体360度画像を得る為の解像度
  #capture.set(3,1440)
  #capture.set(4,1440)

  #360度カメラで生映像で角度を付ける用の縮小サイズ
  size2=(1440,1440)


  #トリミング範囲指定.倒立振子
  #X = 600  #cols
  #Y = 400  #rows
  #Width = 600
  #Height = 600

  #トリミング範囲指定
  X = 650  #cols
  Y = 450  #rows
  Width = 450
  Height = 450


  while cv2.waitKey(30) < 0:
    # キャプチャーする
    _, frame = capture.read()

    #画像回転
    # 画像の中心位置
    # 今回は画像サイズの中心をとっている
    center = tuple(np.array([frame.shape[1] * 0.5, frame.shape[0] * 0.5]))
    # 回転させたい角度
    # ラジアンではなく角度(°)
    #angle = -45.0
    #angle = -8.0
    angle = -53.0
    # 拡大比率
    scale = 1.0
    # 回転変換行列の算出
    rotation_matrix = cv2.getRotationMatrix2D(center, angle, scale)

    # アフィン変換
    frame = cv2.warpAffine(frame, rotation_matrix, size2, flags=cv2.INTER_CUBIC)

    #トリミング
    frame = frame[Y:Y+Height , X:X+Width]

    #リサイズする．
    frame = cv2.resize(frame,size)




    #色（赤）を探してrects配列に矩形(x,y,width,height)として
    #格納する関数を実行 
    rects = find_rect_of_target_color(frame)

    #すべての矩形をframeに追加
    for rect in rects:
      cv2.rectangle(frame, tuple(rect[0:2]), tuple(rect[0:2] + rect[2:4]), (0, 255, 0), thickness=2)


    #一番大きな矩形を探してframeに追加
    #if len(rects) > 0:
    #  rect = max(rects, key=(lambda x: x[2] * x[3]))
    #  print '==='
    #  print rect[0],rect[1] 
    #  cv2.rectangle(frame, tuple(rect[0:2]), tuple(rect[0:2] + rect[2:4]), (0, 0, 255), thickness=2)

    # N max large rectangle 
    N=4
    if len(rects)>N:
      A=[]
      for rect in rects:
         A.append(rect[2]*rect[3]) 

      for num in range(N):
         idx=np.argmax(A)

         if A[idx]>50:
           rect=rects[idx]
           print rect
           cv2.rectangle(frame, tuple(rect[0:2]), tuple(rect[0:2] + rect[2:4]), (0, 0, 255), thickness=2)

         del A[idx]
         del rects[idx]






    # 窓に画像を表示する
    cv2.imshow('PINK !', frame)

    # OUTPUT to File
    out.write(frame)

  capture.release()
  out.release()
  cv2.destroyAllWindows()
